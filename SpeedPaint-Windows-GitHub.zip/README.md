# SpeedPaint untuk Windows

Ubah banyak foto sekaligus menjadi video proses menggambar (SpeedPaint).

## Preset otomatis
- Gaya: Langsung warna, ikuti garis
- Warna goresan sketsa: warna asli foto
- Durasi 60 detik, resolusi 1080p, tahan hasil akhir 3 detik
- Ukuran video otomatis mengikuti tiap foto (1:1, 16:9, 9:16, dll.)
- Hasil disimpan di folder `Hasil` di samping aplikasi (cadangan: Dokumen\SpeedPaint\Hasil)

## Cara pakai
1. Klik "Tambah Foto" dan pilih banyak foto sekaligus.
2. Klik "Buat Video untuk Semua Foto".
3. Buka folder Hasil.

## Menjalankan
- Dari sumber: `run.bat` (butuh Python 3.10+).
- Buat .exe: upload zip ini ke GitHub, jalankan Actions > Build SpeedPaint EXE, unduh artifact `SpeedPaint-Windows`.
