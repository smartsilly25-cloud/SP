"""Pengaturan preset dan pemrosesan banyak foto (tanpa GUI, supaya mudah diuji)."""
from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path

import numpy as np

from . import speedpaint as sp
from .common import load_image, output_dir

# Pilihan (urutan = indeks yang dipakai mesin video)
STYLES = ["Ikuti garis, lalu warna", "Langsung warna (menyapu)", "Ikuti garis saja", "Langsung warna, ikuti garis"]
DIRS = ["Kiri ke kanan", "Atas ke bawah", "Dari tengah keluar", "Acak alami (per bagian, beda tiap video)"]
PAPERS = ["Putih", "Krem", "Papan tulis", "Kertas buku bergaris"]
INKS = ["Otomatis (hitam / putih)", "Biru tua (pulpen)", "Cokelat sepia", "Abu-abu pensil", "Warna asli foto"]
# Rasio: teks -> kode mesin (0 ikuti foto, 1 = 9:16, 2 = 1:1, 3 = 16:9)
RATIOS = [("Otomatis (ikuti foto asli)", 0), ("1:1 (Instagram)", 2), ("16:9 (YouTube)", 3), ("9:16 (Reels/TikTok)", 1)]
RESOLUTIONS = ["720p", "1080p"]
FPS = [24, 30, 60]
HOLDS = ["0 detik", "1 detik", "2 detik", "3 detik"]
SOURCES = ["Otomatis (hitam-putih / foto)", "Tepi saja (untuk foto)", "Area gelap (gambar hitam-putih)"]
SENS = ["Otomatis (sesuai gambar)", "Lebih sedikit garis", "Lebih banyak garis"]
THICK = ["Otomatis (sesuai gambar)", "Tipis", "Sedang", "Tebal"]


@dataclass
class Settings:
    """Preset bawaan: langsung warna ikuti garis, warna asli foto, 60 detik, 1080p, tahan 3 detik."""
    style: int = 3
    direction: int = 3
    paper: int = 0
    ink: int = 4
    seconds: int = 60
    ratio_idx: int = 0
    res_idx: int = 1
    fps_idx: int = 1
    hold: int = 3
    source: int = 0
    sens: int = 0
    thick: int = 0
    hand_on: bool = True
    hand_pct: int = 55
    hand_speed: float = 1.0


def to_options(s: Settings) -> sp.PaintOptions:
    return sp.PaintOptions(
        style=s.style, direction=s.direction, paper=s.paper, ratio=RATIOS[s.ratio_idx][1],
        res=1080 if s.res_idx == 1 else 720, hand_pct=s.hand_pct, hand_speed=s.hand_speed,
        hold_sec=s.hold, fps=FPS[s.fps_idx], sens=s.sens, thick=s.thick, source=s.source, ink=s.ink,
        transparent_src=False)


def unique_path(folder: Path, stem: str) -> Path:
    stem = re.sub(r'[\\/:*?"<>|]+', "_", stem).strip() or "foto"
    p = folder / f"{stem}_speedpaint.mp4"
    i = 2
    while p.exists():
        p = folder / f"{stem}_speedpaint_{i}.mp4"
        i += 1
    return p


def render_one(photo: str, s: Settings, custom_hand: np.ndarray | None = None, cancelled=lambda: False,
               on_progress=lambda p: None, folder: Path | None = None) -> Path | None:
    """Satu foto -> satu video di folder Hasil. Mengembalikan jalur berkas (None bila dibatalkan)."""
    folder = folder or output_dir()
    img = load_image(photo, 1600)                         # foto asli; ukuran video mengikuti foto bila rasio = Otomatis
    hand = None
    if s.hand_on:
        hand = custom_hand if custom_hand is not None else sp.default_hand()
    out = unique_path(folder, Path(photo).stem)
    sp.render(img, s.seconds, str(out), to_options(s), hand, cancelled, on_progress)
    if cancelled():
        try:
            out.unlink()
        except OSError:
            pass
        return None
    return out
