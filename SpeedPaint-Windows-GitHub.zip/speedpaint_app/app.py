"""Antarmuka SpeedPaint (Tkinter): banyak foto sekaligus -> banyak video."""
from __future__ import annotations

import os
import threading
import time
import tkinter as tk
from dataclasses import asdict
from pathlib import Path
from tkinter import filedialog, messagebox, ttk

import numpy as np
from PIL import Image, ImageTk

from . import batch
from .batch import Settings
from .common import asset_path, output_dir

YELLOW, INK, BG, MUTED = "#FFC107", "#111111", "#FFF8E7", "#6B6558"
VERSION = "SpeedPaint 1.0 Windows"
EXTS = ("*.jpg", "*.jpeg", "*.png", "*.webp", "*.bmp", "*.tif", "*.tiff")


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title(VERSION)
        self.geometry("1180x800")
        self.minsize(980, 640)
        self.configure(bg=BG)
        try:
            self.iconphoto(True, tk.PhotoImage(file=str(asset_path("logo_header.png"))))
        except Exception:
            pass
        self.photos: list[str] = []
        self.status_of: dict[str, str] = {}
        self.custom_hand: np.ndarray | None = None
        self.running = False
        self.cancel_flag = False
        self._tkimg = None
        self._logo = None
        self._build()

    # ------------------------------------------------------------------ util UI
    def _build(self):
        st = ttk.Style(self)
        try:
            st.theme_use("clam")
        except tk.TclError:
            pass
        st.configure("Y.TButton", font=("Segoe UI", 10, "bold"), background=YELLOW, foreground=INK, padding=8)
        st.map("Y.TButton", background=[("active", "#ffd54f"), ("disabled", "#e8dcae")])
        st.configure("W.TButton", font=("Segoe UI", 10), padding=6)
        st.configure("TLabelframe", background=BG)
        st.configure("TLabelframe.Label", background=BG, font=("Segoe UI", 10, "bold"))
        st.configure("TLabel", background=BG)
        st.configure("TCheckbutton", background=BG)

        left = tk.Frame(self, bg=BG)
        left.pack(side="left", fill="both", expand=True, padx=(10, 5), pady=10)
        right = tk.Frame(self, bg=BG, width=440)
        right.pack(side="right", fill="y", padx=(5, 10), pady=10)
        right.pack_propagate(False)

        try:
            lg = Image.open(asset_path("logo_header.png")).convert("RGBA")
            lg.thumbnail((200, 80))
            self._logo = ImageTk.PhotoImage(lg)
            tk.Label(left, image=self._logo, bg=BG).pack()
        except Exception:
            pass

        bar = tk.Frame(left, bg=BG)
        bar.pack(fill="x", pady=4)
        self.btn_add = ttk.Button(bar, text="Tambah Foto (bisa banyak)...", style="Y.TButton", command=self.add_photos)
        self.btn_add.pack(side="left", fill="x", expand=True)
        self.btn_rm = ttk.Button(bar, text="Hapus", style="W.TButton", command=self.remove_selected)
        self.btn_rm.pack(side="left", padx=4)
        self.btn_clear = ttk.Button(bar, text="Kosongkan", style="W.TButton", command=self.clear_all)
        self.btn_clear.pack(side="left")

        mid = tk.Frame(left, bg=BG)
        mid.pack(fill="both", expand=True)
        lf = tk.Frame(mid, bg=BG, width=300)
        lf.pack(side="left", fill="y")
        lf.pack_propagate(False)
        self.lb = tk.Listbox(lf, selectmode="extended", activestyle="none", font=("Segoe UI", 10), exportselection=False)
        sb = ttk.Scrollbar(lf, orient="vertical", command=self.lb.yview)
        self.lb.configure(yscrollcommand=sb.set)
        self.lb.pack(side="left", fill="both", expand=True)
        sb.pack(side="right", fill="y")
        self.lb.bind("<<ListboxSelect>>", lambda e: self.show_preview())
        self.canvas = tk.Canvas(mid, bg="#F4EFE0", highlightthickness=2, highlightbackground=INK)
        self.canvas.pack(side="left", fill="both", expand=True, padx=(6, 0))
        self.canvas.bind("<Configure>", lambda e: self.show_preview())

        self.count_lbl = tk.Label(left, bg=BG, fg=MUTED, anchor="w", text="Belum ada foto. Klik 'Tambah Foto' lalu pilih banyak foto sekaligus (Ctrl/Shift).")
        self.count_lbl.pack(fill="x", pady=(6, 0))
        self.folder_lbl = tk.Label(left, bg=BG, fg=INK, anchor="w", justify="left", wraplength=640,
                                   text="Video disimpan ke: " + str(output_dir()))
        self.folder_lbl.pack(fill="x")
        ttk.Button(left, text="Buka Folder Hasil", style="W.TButton", command=self.open_folder).pack(anchor="w", pady=4)

        # ---------- panel pengaturan (bisa di-scroll)
        outer = tk.Frame(right, bg=BG)
        outer.pack(fill="both", expand=True)
        cv = tk.Canvas(outer, bg=BG, highlightthickness=0)
        vs = ttk.Scrollbar(outer, orient="vertical", command=cv.yview)
        inner = tk.Frame(cv, bg=BG)
        inner.bind("<Configure>", lambda e: cv.configure(scrollregion=cv.bbox("all")))
        win = cv.create_window((0, 0), window=inner, anchor="nw")
        cv.bind("<Configure>", lambda e: cv.itemconfigure(win, width=e.width))
        cv.configure(yscrollcommand=vs.set)
        cv.pack(side="left", fill="both", expand=True)
        vs.pack(side="right", fill="y")
        cv.bind("<Enter>", lambda e: cv.bind_all("<MouseWheel>", lambda ev: cv.yview_scroll(int(-ev.delta / 120), "units")))
        cv.bind("<Leave>", lambda e: cv.unbind_all("<MouseWheel>"))
        self.settings_parent = inner
        self.controls: list = []
        self._build_settings(inner)

        act = tk.Frame(right, bg=BG)
        act.pack(fill="x", pady=(6, 0))
        self.gen_btn = ttk.Button(act, text="Buat Video untuk Semua Foto", style="Y.TButton", command=self.start)
        self.gen_btn.pack(fill="x")
        self.cancel_btn = ttk.Button(act, text="Batalkan", style="W.TButton", command=self.cancel)
        self.bar_one = ttk.Progressbar(act, maximum=100)
        self.bar_all = ttk.Progressbar(act, maximum=100)

        self.status = tk.Label(self, text=VERSION, bg=BG, fg=MUTED, anchor="w")
        self.status.pack(side="bottom", fill="x", padx=10)

    def _box(self, title):
        f = ttk.LabelFrame(self.settings_parent, text=title, padding=8)
        f.pack(fill="x", padx=6, pady=5)
        return f

    def _combo(self, parent, label, items, sel=0):
        ttk.Label(parent, text=label, foreground=MUTED).pack(anchor="w", pady=(6, 0))
        v = tk.StringVar(value=items[sel])
        c = ttk.Combobox(parent, textvariable=v, values=items, state="readonly")
        c.pack(fill="x")
        c.var = v                      # simpan referensi supaya nilainya tidak hilang
        c.items = items
        c.idx = lambda c=c: c.items.index(c.get())
        c.set_idx = lambda i, c=c: c.set(c.items[i])
        self.controls.append(c)
        return c

    def _slider(self, parent, fmt, lo, hi, init):
        row = tk.Frame(parent, bg=BG)
        row.pack(fill="x", pady=(6, 0))
        lbl = tk.Label(row, bg=BG, anchor="w", text=fmt(init))
        lbl.pack(fill="x")
        var = tk.IntVar(value=init)
        sc = ttk.Scale(row, from_=lo, to=hi, variable=var, orient="horizontal",
                       command=lambda v: (var.set(int(float(v))), lbl.config(text=fmt(var.get()))))
        sc.pack(fill="x")
        sc.var, sc.lbl, sc.fmt = var, lbl, fmt
        sc.get_i = lambda: var.get()
        sc.set_i = lambda v, sc=sc: (sc.var.set(v), sc.lbl.config(text=sc.fmt(v)))
        self.controls.append(sc)
        return sc

    def _build_settings(self, p):
        d = Settings()
        tk.Label(p, bg=BG, fg=MUTED, anchor="w", justify="left", wraplength=400,
                 text="Pengaturan sudah diset ke preset: langsung warna ikuti garis, warna asli foto, 60 detik, 1080p, tahan 3 detik. Ukuran video otomatis mengikuti tiap foto.").pack(fill="x", padx=6, pady=(2, 0))
        ttk.Button(p, text="Kembalikan ke Preset", style="W.TButton", command=self.reset_preset).pack(fill="x", padx=6, pady=4)

        c = self._box("Gaya menggambar")
        self.c_style = self._combo(c, "Gaya", batch.STYLES, d.style)
        self.c_dir = self._combo(c, "Arah", batch.DIRS, d.direction)
        self.c_paper = self._combo(c, "Latar kertas", batch.PAPERS, d.paper)
        self.c_ink = self._combo(c, "Warna goresan sketsa", batch.INKS, d.ink)

        c = self._box("Video")
        self.s_dur = self._slider(c, lambda v: f"Durasi: {v} detik", 5, 60, d.seconds)
        self.c_ratio = self._combo(c, "Rasio / ukuran video", [r[0] for r in batch.RATIOS], d.ratio_idx)
        self.c_res = self._combo(c, "Resolusi", batch.RESOLUTIONS, d.res_idx)
        self.c_fps = self._combo(c, "FPS video", [f"{f} fps" for f in batch.FPS], d.fps_idx)
        self.c_hold = self._combo(c, "Tahan hasil akhir", batch.HOLDS, d.hold)

        c = self._box("Deteksi garis")
        self.c_source = self._combo(c, "Sumber garis", batch.SOURCES, d.source)
        self.c_sens = self._combo(c, "Kepekaan garis", batch.SENS, d.sens)
        self.c_thick = self._combo(c, "Ketebalan garis", batch.THICK, d.thick)

        c = self._box("Tangan")
        self.hand_on = tk.BooleanVar(value=d.hand_on)
        cb = ttk.Checkbutton(c, text="Tampilkan gambar tangan", variable=self.hand_on)
        cb.pack(anchor="w")
        self.controls.append(cb)
        self.s_hand = self._slider(c, lambda v: f"Ukuran tangan: {v}%", 20, 100, d.hand_pct)
        self.s_speed = self._slider(c, lambda v: f"Kecepatan gerak tangan: x{v / 10:.1f}", 5, 30, int(d.hand_speed * 10))
        self.hand_lbl = tk.Label(c, text="Tangan: bawaan", bg=BG, fg=MUTED)
        self.hand_lbl.pack(anchor="w", pady=4)
        r = tk.Frame(c, bg=BG)
        r.pack(fill="x")
        b1 = ttk.Button(r, text="Ganti tangan (PNG)", style="W.TButton", command=self.pick_hand)
        b1.pack(side="left")
        b2 = ttk.Button(r, text="Bawaan", style="W.TButton", command=self.reset_hand)
        b2.pack(side="left", padx=6)
        self.controls += [b1, b2]

    def reset_preset(self):
        d = Settings()
        self.c_style.set_idx(d.style); self.c_dir.set_idx(d.direction); self.c_paper.set_idx(d.paper)
        self.c_ink.set_idx(d.ink); self.s_dur.set_i(d.seconds); self.c_ratio.set_idx(d.ratio_idx)
        self.c_res.set_idx(d.res_idx); self.c_fps.set_idx(d.fps_idx); self.c_hold.set_idx(d.hold)
        self.c_source.set_idx(d.source); self.c_sens.set_idx(d.sens); self.c_thick.set_idx(d.thick)
        self.hand_on.set(d.hand_on); self.s_hand.set_i(d.hand_pct); self.s_speed.set_i(int(d.hand_speed * 10))
        self.set_status("Pengaturan dikembalikan ke preset.")

    def current_settings(self) -> Settings:
        return Settings(
            style=self.c_style.idx(), direction=self.c_dir.idx(), paper=self.c_paper.idx(), ink=self.c_ink.idx(),
            seconds=self.s_dur.get_i(), ratio_idx=self.c_ratio.idx(), res_idx=self.c_res.idx(),
            fps_idx=self.c_fps.idx(), hold=self.c_hold.idx(), source=self.c_source.idx(), sens=self.c_sens.idx(),
            thick=self.c_thick.idx(), hand_on=self.hand_on.get(), hand_pct=self.s_hand.get_i(),
            hand_speed=self.s_speed.get_i() / 10.0)

    # ------------------------------------------------------------------ daftar foto
    def set_status(self, t):
        self.after(0, lambda: self.status.config(text=t))

    def refresh_list(self):
        sel = self.lb.curselection()
        self.lb.delete(0, "end")
        for i, p in enumerate(self.photos):
            mark = self.status_of.get(p, "")
            self.lb.insert("end", f"{i + 1}. {Path(p).name}  {mark}")
        for i in sel:
            if i < len(self.photos):
                self.lb.selection_set(i)
        n = len(self.photos)
        self.count_lbl.config(text=f"{n} foto siap diproses." if n else "Belum ada foto. Klik 'Tambah Foto' lalu pilih banyak foto sekaligus (Ctrl/Shift).")

    def add_photos(self):
        fs = filedialog.askopenfilenames(title="Pilih foto (bisa banyak)", filetypes=[("Gambar", " ".join(EXTS)), ("Semua", "*.*")])
        for f in fs:
            if f not in self.photos:
                self.photos.append(f)
                self.status_of.pop(f, None)
        self.refresh_list()
        if self.photos and not self.lb.curselection():
            self.lb.selection_set(len(self.photos) - len(fs))
        self.show_preview()

    def remove_selected(self):
        for i in sorted(self.lb.curselection(), reverse=True):
            self.photos.pop(i)
        self.refresh_list()
        self.show_preview()

    def clear_all(self):
        if self.running:
            return
        self.photos.clear()
        self.status_of.clear()
        self.refresh_list()
        self.show_preview()

    def show_preview(self):
        self.canvas.delete("all")
        cw, ch = max(10, self.canvas.winfo_width()), max(10, self.canvas.winfo_height())
        sel = self.lb.curselection()
        path = self.photos[sel[0]] if sel and sel[0] < len(self.photos) else (self.photos[0] if self.photos else None)
        if not path:
            self.canvas.create_text(cw // 2, ch // 2, text="Belum ada foto", fill=MUTED, font=("Segoe UI", 12))
            return
        try:
            from PIL import ImageOps
            im = ImageOps.exif_transpose(Image.open(path)).convert("RGB")
            W, H = im.size
            im.thumbnail((cw - 8, ch - 40))
            self._tkimg = ImageTk.PhotoImage(im)
            self.canvas.create_image(cw // 2, (ch - 24) // 2, image=self._tkimg)
            self.canvas.create_text(cw // 2, ch - 12, text=f"{Path(path).name}   {W}x{H}", fill=MUTED)
        except Exception as e:  # noqa: BLE001
            self.canvas.create_text(cw // 2, ch // 2, text=f"Tidak bisa dibuka: {e}", fill=MUTED)

    # ------------------------------------------------------------------ tangan / folder
    def pick_hand(self):
        f = filedialog.askopenfilename(title="Pilih gambar tangan (PNG transparan)", filetypes=[("PNG", "*.png"), ("Gambar", "*.png *.webp")])
        if f:
            try:
                self.custom_hand = np.array(Image.open(f).convert("RGBA"))
                self.hand_lbl.config(text="Tangan: gambar pilihan Anda")
            except Exception as e:  # noqa: BLE001
                messagebox.showerror("Gagal", str(e))

    def reset_hand(self):
        self.custom_hand = None
        self.hand_lbl.config(text="Tangan: bawaan")

    def open_folder(self):
        d = output_dir()
        try:
            os.startfile(str(d))  # type: ignore[attr-defined]
        except Exception:
            messagebox.showinfo("Folder hasil", str(d))

    # ------------------------------------------------------------------ proses antrean
    def set_running(self, on: bool):
        self.running = on
        for c in self.controls + [self.btn_add, self.btn_rm, self.btn_clear]:
            try:
                c.state(["disabled"] if on else ["!disabled"])
            except Exception:
                pass
        if on:
            self.gen_btn.state(["disabled"])
            self.cancel_btn.pack(fill="x", pady=3)
            self.bar_one.pack(fill="x", pady=(3, 0))
            self.bar_all.pack(fill="x", pady=3)
        else:
            self.gen_btn.state(["!disabled"])
            self.cancel_btn.pack_forget()
            self.bar_one.pack_forget()
            self.bar_all.pack_forget()

    def cancel(self):
        self.cancel_flag = True
        self.set_status("Membatalkan...")

    def start(self):
        if self.running:
            return
        if not self.photos:
            messagebox.showinfo("Foto", "Tambahkan foto dulu.")
            return
        s = self.current_settings()
        hand = self.custom_hand
        todo = list(self.photos)
        self.cancel_flag = False
        for p in todo:
            self.status_of[p] = "(menunggu)"
        self.refresh_list()
        self.set_running(True)
        self.bar_one["value"] = 0
        self.bar_all["value"] = 0
        folder = output_dir()

        def work():
            ok = fail = 0
            t0 = time.time()
            for i, p in enumerate(todo):
                if self.cancel_flag:
                    break
                self.status_of[p] = "(diproses...)"
                self.after(0, self.refresh_list)
                self.set_status(f"Video {i + 1} dari {len(todo)}: {Path(p).name}")
                try:
                    out = batch.render_one(
                        p, s, hand, lambda: self.cancel_flag,
                        lambda pr, i=i: self.after(0, lambda: (self.bar_one.configure(value=pr),
                                                                self.bar_all.configure(value=(i + pr / 100.0) * 100.0 / len(todo)))),
                        folder)
                    if out is None:
                        self.status_of[p] = "(dibatalkan)"
                    else:
                        self.status_of[p] = "(selesai)"
                        ok += 1
                except Exception as e:  # noqa: BLE001
                    self.status_of[p] = "(GAGAL)"
                    fail += 1
                    self.set_status(f"Gagal pada {Path(p).name}: {e}")
                self.after(0, self.refresh_list)
            dt = int(time.time() - t0)
            msg = f"Selesai: {ok} video berhasil" + (f", {fail} gagal" if fail else "") + f" ({dt // 60} mnt {dt % 60} dtk). Folder: {folder}"
            if self.cancel_flag:
                msg = "Dibatalkan. " + msg
            self.set_status(msg)
            self.after(0, lambda: self.set_running(False))
            if ok and not self.cancel_flag:
                self.after(0, lambda: messagebox.showinfo("Selesai", msg))
        threading.Thread(target=work, daemon=True).start()


def main():
    App().mainloop()
