"""Fungsi bantu: lokasi berkas, folder Hasil, baca gambar."""
from __future__ import annotations

import os
import sys
from pathlib import Path

import cv2
import numpy as np


def app_dir() -> Path:
    """Folder sumber/paket (untuk assets); mendukung PyInstaller."""
    if getattr(sys, "frozen", False):
        return Path(getattr(sys, "_MEIPASS", Path(sys.executable).parent))
    return Path(__file__).resolve().parent.parent


def asset_path(name: str) -> Path:
    return app_dir() / "assets" / name


def exe_dir() -> Path:
    """Folder tempat aplikasi berada (SpeedPaint.exe, atau main.py saat dijalankan dari sumber)."""
    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parent.parent


def output_dir() -> Path:
    """Folder 'Hasil' di samping aplikasi. Bila tidak bisa ditulis (mis. Program Files): Documents\\SpeedPaint\\Hasil."""
    for base in (exe_dir(), Path(os.path.expanduser("~")) / "Documents" / "SpeedPaint"):
        p = base / "Hasil"
        try:
            p.mkdir(parents=True, exist_ok=True)
            probe = p / ".tulis"
            probe.write_text("x")
            probe.unlink()
            return p
        except OSError:
            continue
    return Path(os.path.expanduser("~"))


def to_rgba(img: np.ndarray) -> np.ndarray:
    if img.ndim == 2:
        img = np.stack([img] * 3, -1)
    if img.shape[2] == 3:
        a = np.full(img.shape[:2] + (1,), 255, np.uint8)
        img = np.concatenate([img, a], 2)
    return np.ascontiguousarray(img)


def load_image(path: str, max_side: int | None = None) -> np.ndarray:
    """Baca gambar (hormati rotasi EXIF) -> RGBA uint8; transparansi dilebur ke putih."""
    from PIL import Image, ImageOps

    im = Image.open(path)
    im = ImageOps.exif_transpose(im)
    if im.mode not in ("RGB", "RGBA"):
        im = im.convert("RGBA" if ("A" in im.getbands() or im.mode == "P") else "RGB")
    arr = to_rgba(np.array(im))
    if (arr[..., 3] < 255).any():
        a = arr[..., 3:4].astype(np.float32) / 255.0
        rgb = arr[..., :3].astype(np.float32) * a + 255.0 * (1 - a)
        arr = to_rgba(np.clip(rgb + 0.5, 0, 255).astype(np.uint8))
    if max_side:
        h, w = arr.shape[:2]
        m = max(h, w)
        if m > max_side:
            s = max_side / m
            arr = cv2.resize(arr, (max(1, int(w * s)), max(1, int(h * s))), interpolation=cv2.INTER_AREA)
    return arr
